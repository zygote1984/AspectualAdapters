package zygote.binding.example.shapes;

public class Circle extends Shape {
	
	
	int r;
	
	public Circle(int r){
		this.r = r;
	}
	
	public int getR() {
		return r;
	}
	
	public void setR(int r) {
		this.r = r;
	}

}
