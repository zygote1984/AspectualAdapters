package zygote.binding.example.shapes;

public interface ShapeArea {

	public String getArea();
}
