package zygote.binding.example.shapes;

public interface ShapeCircum {
	
	public String getCircum();

}
