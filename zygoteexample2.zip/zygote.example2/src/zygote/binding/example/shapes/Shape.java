package zygote.binding.example.shapes;

public abstract class Shape {

}
